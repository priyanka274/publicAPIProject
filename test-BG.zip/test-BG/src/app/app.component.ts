import { Component } from '@angular/core';
import {AdviceSlipService } from './advice-slip.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(private service: AdviceSlipService) { }
  public response: String[]  = [];
  slip: slip;
  page = 5;
  pageSize = 5;

  onSubmit() {
    let check=[]
    this.service.getAll().subscribe((slip: slipObj) => {
      if (slip) {
        if (!this.response.includes(slip.slip.advice)) {
          this.response.push(slip.slip.advice); 
        }
        this.response = this.response.sort((a, b) => a > b ? 1 : -1);
      }
    });
  }
}
    
export interface slip {
  Id?: Number;
  advice: String;
}

export interface slipObj {
        slip: slip;
      }


